package br.com.fatecararas.domain;

import java.util.Map;


public class Tesoura extends Algoritmo{

    @Override
    public Map<String, String> executar(Tipo pTipo){
        switch(pTipo){
            case PAPEL -> valor = "Ganhou. Tesoura cobre papel!";
            case TESOURA -> valor = "Empate. Tesoura empata com tesoura!";
            case PEDRA -> valor = "Perdeu. Pedra esmaga tesoura!";
            default -> valor = "Empatou. Opcao invalida!";
        }
        
        resultado.put(KEY, valor);
        return resultado;
        }
    }
    
    
    

