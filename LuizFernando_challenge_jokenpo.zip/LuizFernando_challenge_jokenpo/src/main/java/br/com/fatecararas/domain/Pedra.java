package br.com.fatecararas.domain;

import java.util.Map;

public class Pedra extends Algoritmo{

    @Override
    public Map<String, String> executar(Tipo pTipo) {
        switch(pTipo){
            case PAPEL -> valor = "Perdeu. Papel cobre pedra!";
            case TESOURA -> valor = "Ganhou. Pedra esmaga tesoura!";
            case PEDRA -> valor = "Empate. Pedra empata com pedra!";
            default -> valor = "Empatou! Opcao invalida!";
        }
        
        resultado.put(KEY, valor);
        return resultado;
    }
}
