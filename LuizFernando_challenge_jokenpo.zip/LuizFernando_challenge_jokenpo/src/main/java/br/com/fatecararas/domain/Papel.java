package br.com.fatecararas.domain;

import java.util.Map;

public class Papel extends Algoritmo{

    @Override
    public Map<String, String> executar(Tipo pTipo){
        switch (pTipo) {
            case PAPEL -> valor = "Empate. Papel empata com papel!";
            case TESOURA -> valor = "Perdeu! Tesoura cobre papel!";
            case PEDRA -> valor = "Ganhou! Papel cobre pedra!";
            default -> valor = "Empatou! Opcao invalida!";
        }

        resultado.put(KEY, valor);
        return resultado;
    }
}
